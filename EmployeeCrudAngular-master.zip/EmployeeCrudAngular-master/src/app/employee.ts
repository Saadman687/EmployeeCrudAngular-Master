 export class Employee {
  id!: number;
  name!: string;
  phone!: number;
  email!: string;
}
 